import { BaseController } from "@/controllers/base.controller";

export class TestController extends BaseController {
  // Réservé aux professionnels
  async proOnly() {
    try {
      const session = await this.requireSession("PROFESSIONAL");
      return this.ok({ message: "Bienvenue professionnel numéro " + session.userId });
    } catch (error) {
      return this.handleError(error);
    }
  }
}