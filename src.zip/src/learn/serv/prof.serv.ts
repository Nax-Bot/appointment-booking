import { ProfessionalRepository, UpdateProfileData } from "@/repositories/professional.repository";

import { NotFoundError, ValidationError } from "@/lib/server/http/errors";

// Les proprietes professional montrée dans le frontend ![email , mot_de_passe]
export interface ProfessionalPublic {
    userId: number;
    firstName: string;
    lastName: string;
    specialty: string | null;
    description: string | null;
}

// Repository => [ Forme d'un professionnel ]
interface ProfessionalRow {
    userId: number;
    description: string | null;
    specialty: string | null;
    user: { firstName: string; lastName: string };
}

export class ProfServ {
    private profRepo: ProfessionalRepository;

    constructor(professionalRepo: ProfessionalRepository) {
        this.profRepo = professionalRepo;
    }


    // Liste en tant que tableau [ProfessionalPublic]
    async listAll(): Promise<ProfessionalPublic[]> {
        const rows = await this.profRepo.findAll();

        // tableau vide pour recuperer les valeurs et les lister dans le tableau
        const profs: ProfessionalPublic[] = [];

        for (const prof of rows) {
            profs.push(this.toPublic(prof));
        }

        return profs;
    }

    // Recuperation d'un professeur
    async getById(id: number): Promise<ProfessionalPublic> {
        const prof: ProfessionalRow | null = await this.profRepo.findById(id);

        if (!prof) {
            throw new NotFoundError("Professionel Non trouvée");
        }

        return this.toPublic(prof);
    }

    // Mise a jour du profile Utilisateur professionel 
    async updateProfile(id: number, data: UpdateProfileData): Promise<ProfessionalPublic> {

        if (data.description === undefined && data.specialty === undefined) {
            throw new ValidationError("Aucune donnée à modifier", []);
        }

        const existing = await this.profRepo.findById(id);

        if (!existing) {
            throw new NotFoundError("Professionel introuvable");
        }
        // soit le Repo renvoye un ProfessionalRow[NON NULLABLE] ou Undefined
        const updateProfil: ProfessionalRow | undefined = await this.profRepo.updateProfile(id, data);

        return this.toPublic(updateProfil);
    }


    // ------- TOUT PARAMETRE D'UNE FONCTION EN TYPESCRIPT DOIT ETRE TYPÉE EXPLICITEMENT

    // Met le professionnel à plat : nom et prénom au même niveau que le reste
    private toPublic(row: ProfessionalRow): ProfessionalPublic {
        return {
            userId: row.userId,
            firstName: row.user.firstName,
            lastName: row.user.lastName,
            specialty: row.specialty,
            description: row.description,
        };
    }
}