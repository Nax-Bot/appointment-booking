import { UnavailabilityData, UnavailabilityRepository } from "@/repositories/unavailability.repository";
import { ProfessionalRepository } from "@/repositories/professional.repository";
import { NotFoundError, ConflictError, ValidationError } from "@/lib/errors";

// Donnée entrant dans le service
export interface UnavailabilityInput {
    startDatetime: string;
    endDatetime: string;
    reason?: string | null;
}

// Donnée de Sortie
// Ce que l'on renvoie (dates en UTC, au format ISO)
export interface UnavailabilityItem {
    id: number;
    startDatetime: string;
    endDatetime: string;
    reason: string | null;
}

// Donnée Recuperer depuis la base de donnée
// Forme d'une indisponibilité telle que le repository la renvoie
interface UnavailabilityRow {
    id: number;
    startDatetime: Date;
    endDatetime: Date;
    reason: string | null;
}

export class UnavailabilityServ {
    private unavailabilityRepo: UnavailabilityRepository;
    private profRepo: ProfessionalRepository;

    constructor(profRepo: ProfessionalRepository, unavailableRepo: UnavailabilityRepository) {
        this.unavailabilityRepo = unavailableRepo;
        this.profRepo = profRepo;
    }

    async getAllByProf(profId: number): Promise<UnavailabilityItem[]> {
        await this.checkProfessionalExists(profId);

        const rows = await this.unavailabilityRepo.findByProfessional(profId);

        const result: UnavailabilityItem[] = [];
        for (const row of rows) {
            result.push(this.toItem(row));
        }

        return result;
    }

    async set(profId: number, input: UnavailabilityInput): Promise<UnavailabilityItem> {
        await this.checkProfessionalExists(profId);

        const data = await this.prepareData(profId, input, null);
        const row = await this.unavailabilityRepo.create(profId, data);

        return this.toItem(row);

    }

    async update(profId: number, input: UnavailabilityInput, unavailabilityId: number): Promise<UnavailabilityItem> {
        await this.checkProfessionalExists(profId);
        const existing = await this.unavailabilityRepo.findOwned(unavailabilityId, profId);

        if (!existing) {
            throw new NotFoundError("Indisponibilite introuvable");
        }

        const data = await this.prepareData(profId, input, unavailabilityId);
        const row = await this.unavailabilityRepo.update(profId, data);

        return this.toItem(row);
    }

    async remove(profId: number, unavailabilityId: number) {
        await this.checkProfessionalExists(profId);
        const existing = await this.unavailabilityRepo.findOwned(unavailabilityId, profId);

        if (!existing) {
            throw new NotFoundError("Indisponibilite introuvable");
        }

        await this.unavailabilityRepo.delete(unavailabilityId);
        return {
            message: "Suppression reussies de l'indisponibilité"
        }
    }

    // Logique metier pour les preparation de données pour le Repository
    private async prepareData(
        profId: number,
        input: UnavailabilityInput,
        ignoreId: number | null
    ): Promise<UnavailabilityData> {

        const start = new Date(input.startDatetime);
        const end = new Date(input.endDatetime);

        if (start.getTime() > end.getTime()) {
            throw new ValidationError("La date de fin doit etre apres la date de debut", []);
        }

        // MODIFICATION /> isItself -> on ignore les verifications pour la ligne concernée
        // repository pour verifier l'overlapping
        const overlapping = await this.unavailabilityRepo.findOverlapping(profId, start, end);

        for (const other of overlapping) {
            let isItself = false;
            if (ignoreId !== null && other.id === ignoreId) {
                isItself = true;
            }

            if (isItself === false) {
                throw new ConflictError("Cette periode chevauche une autre indisponibilite");
            }
        }

        let reason: string | null = null;

        if (input.reason !== null && input.reason !== undefined) {
            reason = input.reason;
        }

        return {
            startDatetime: start,
            endDatetime: end,
            reason: reason
        }


    }

    private async checkProfessionalExists(profId: number) {
        const checkProf = await this.profRepo.findById(profId);

        if (!checkProf) {
            throw new NotFoundError("Professional Introuvable");
        }
    }

    // Transforme une ligne de la base en réponse simple (dates en UTC)
    private toItem(row: UnavailabilityRow): UnavailabilityItem {
        return {
            id: row.id,
            startDatetime: row.startDatetime.toISOString(),
            endDatetime: row.endDatetime.toISOString(),
            reason: row.reason,
        };
    }
}