import { AvailabilityData, AvailabilityRepository } from "@/repositories/availability.repository";
import { ProfessionalRepository } from "@/repositories/professional.repository";
import { ConflictError, NotFoundError, ValidationError } from "@/lib/server/http/errors";

// Ce qu'on recupere depuis le Corps JSON -> Route -> Controller 
export interface AvailabilityInputRepo {
    dayOfWeek: number;
    startTime: string;
    endTime: string;
    validFrom?: string | null;
    validTo?: string | null;
}

// Ce qu'on renvoie au -> Controller -> A L'UTILISATEUR
export interface AvailabilityItem {
    id: number;
    dayOfWeek: number;
    startTime: string;
    endTime: string;
    validFrom: string | null;
    validTo: string | null;
}

// Ce qu'on recoit depuis le Repository
interface AvailabilityRow {
    id: number;
    dayOfWeek: number;
    startTime: Date;
    endTime: Date;
    validFrom: Date | null;
    validTo: Date | null;
}


export class AvailibilityServ {
    private availabilityRepo: AvailabilityRepository;
    private professionalRepo: ProfessionalRepository;

    constructor(
        availableRepo: AvailabilityRepository,
        professionalRepo: ProfessionalRepository
    ) {
        this.availabilityRepo = availableRepo;
        this.professionalRepo = professionalRepo;
    }

    async set(profId: number, availabilityId: number, AvailabilityData: AvailabilityInputRepo): Promise<AvailabilityItem> {
        await this.checkProfessionalExists(profId);

        const data = await this.prepareData(
            profId,
            AvailabilityData,
            null
        )
        const row = await this.availabilityRepo.create(profId, data);

        return this.toItem(row);

    }

    async getByProf(profId: number): Promise<AvailabilityRow[]> {
        await this.checkProfessionalExists(profId);

        const rows = await this.availabilityRepo.findByProfessional(profId);
        const result: AvailabilityRow[] = [];

        for (const row of rows) {
            result.push(row);
        }

        return result;
    }

    async update(profId: number, availabilityId: number, input: AvailabilityInputRepo) {
        await this.checkProfessionalExists(profId);

        // Preparation de l'input pour introduire dans le Repository 
        // AvailabilityInputRepo -> AvailabilityData
        const data = await this.prepareData(
            profId,
            input,
            availabilityId
        );
        const row = await this.availabilityRepo.update(availabilityId, data);

        return this.toItem(row);

    }

    async remove(profId: number, availabilityId: number) {
        await this.checkProfessionalExists(profId);

        const checkAvailability = await this.availabilityRepo.findOwned(profId, availabilityId);

        if (!checkAvailability) {
            throw new NotFoundError("Disponibilite introuvable");
        }

        await this.availabilityRepo.delete(availabilityId);

        return {
            message: "Disponibilité supprimée avec succès"
        };
    }

    private async prepareData(
        profId: number,
        input: AvailabilityInputRepo,
        ignoreId: number | null
    ): Promise<AvailabilityData> {
        // ---------------- HEURE
        if (input.startTime >= input.endTime) {
            throw new ValidationError("L'heure de fin doit etre apres l'heure de debut", []);
        }

        // ---------------- DATE DE VALIDITE
        let validFromText: string | null = null;
        let validFrom: Date | null = null;

        if (input.validFrom !== undefined && input.validFrom !== null) {
            // Parser en Type Date 
            validFrom = this.parseDateOnly(input.validFrom, "validFrom");

            validFromText = input.validFrom;
        }

        let validToText: string | null = null;
        let validTo: Date | null = null;

        if (input.validTo !== undefined && input.validTo !== null) {
            // Parser en Type Date
            validTo = this.parseDateOnly(input.validTo, "validTo");

            validToText = input.validTo;
        }

        if (validFromText !== null && validToText !== null) {
            if (validFromText > validToText) {
                throw new ValidationError("La fin de validité ne peut pas etre avant le debut de validite", []);
            }
        }

        // --------------- AUCUNE CHEVAUCHEMENT AVEC UNE AUTRE DISPONIBLITE
        await this.checkNoOverLap(
            profId,
            input,
            validFromText,
            validToText,
            ignoreId
        );

        return {
            dayOfWeek: input.dayOfWeek,
            startTime: this.textToTime(input.startTime),
            endTime: this.textToTime(input.endTime),
            validFrom: validFrom,
            validTo: validTo
        }

    }

    private async checkProfessionalExists(professionalId: number) {
        const profIdCheck = await this.professionalRepo.findById(professionalId);
        if (!profIdCheck) {
            throw new NotFoundError("Professionel Introuvable");
        }
    };

    private async checkNoOverLap(
        professionalId: number,
        input: AvailabilityInputRepo,
        validFromText: string | null,
        validToText: string | null,
        ignoreId: number | null
    ) {
        const sameDay = await this.availabilityRepo.findByProfessionalAndDay(professionalId, input.dayOfWeek);

        for (const other of sameDay) {
            let isItself = false;
            // Null pour create / Not null pour update
            if (ignoreId !== null && other.id === ignoreId) {
                isItself = true;
            }
            if (isItself === false) {
                const otherStart = this.timeToText(other.startTime);
                const otherEnd = this.timeToText(other.endTime);

                // ["11:00"-"13:00"] -> ["8:00"-"12:00"]
                const timesOverlap = input.startTime < otherEnd && input.endTime > otherStart;

                // Chevauchement entre les plages de dates du debut du validité et fin du validité
                // [2026/10/26 - 2026/10/30] -> [2026/11/01 - 2026/11/04]
                if (timesOverlap) {
                    let otherFrom: string | null = null;
                    if (other.validFrom !== null) {
                        otherFrom = this.dateToText(other.validFrom);
                    }

                    let otherTo: string | null = null;
                    if (other.validTo !== null) {
                        otherTo = this.dateToText(other.validTo);
                    }

                    if (this.periodsOverlap(validFromText, validToText, otherFrom, otherTo)) {
                        throw new ConflictError("Cette plage horaire chevauche une autre disponibilité");
                    }

                }
            }
        }
    }

    // Deux périodes se recoupent, sauf si l'une commence après la fin de l'autre (null = sans limite)
    private periodsOverlap(
        fromA: string | null,
        toA: string | null,
        fromB: string | null,
        toB: string | null
    ): boolean {
        if (fromA !== null && toB !== null && fromA > toB) {
            return false;
        }
        if (fromB !== null && toA !== null && fromB > toA) {
            return false;
        }
        return true;
    }

    // "AAAA-MM-JJ" => Date , et refuse les dates qui sont invalides 
    private parseDateOnly(text: string, fieldName: string): Date {
        const date = new Date(text + "T00:00:00.000Z");

        if (Number.isNaN(date.getTime()) || date.toISOString().substring(0, 10) !== text) {
            throw new ValidationError("Données invalides", [fieldName + " : cette date n'existe pas"]);
        }

        return date;
    }

    // "08:00" devient une Date du 1er janvier 1970 à 08:00 (c'est ce que Prisma attend pour une colonne Time)
    private textToTime(text: string): Date {
        return new Date("1970-01-01T" + text + ":00.000Z");
    }

    // Inverse : Date -> "08:00"
    private timeToText(date: Date): string {
        return date.toISOString().substring(11, 16);
    }

    // Date -> "AAAA-MM-JJ"
    private dateToText(date: Date): string {
        return date.toISOString().substring(0, 10);
    }


    // Transforme une ligne de la base en réponse simple
    private toItem(row: AvailabilityRow): AvailabilityItem {
        let validFrom: string | null = null;
        if (row.validFrom !== null) {
            validFrom = this.dateToText(row.validFrom);
        }

        let validTo: string | null = null;
        if (row.validTo !== null) {
            validTo = this.dateToText(row.validTo);
        }

        return {
            id: row.id,
            dayOfWeek: row.dayOfWeek,
            startTime: this.timeToText(row.startTime),
            endTime: this.timeToText(row.endTime),
            validFrom: validFrom,
            validTo: validTo,
        };
    }

}