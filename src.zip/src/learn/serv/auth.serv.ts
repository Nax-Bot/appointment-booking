import { UserRepository, NewUserData } from "@/repositories/user.repository";
import { ConflictError, UnauthorizedError } from "@/lib/errors";
// Importation des fonctions - [mot de passe] / bcrypt
import { hashPassword, verifyPassword, Role } from "@/lib/auth";
import { email } from "zod";

// On declare une variable avec cet interface
export interface RegisterBody {
    role: Role,
    lastName: string;
    firstName: string;
    email: string;
    password: string;
    phoneNumber?: string;
}

export interface LoginBody {
    email: string;
    password: string;
}

// Profil utilisateur => AuthUserCop
export interface UserProfilMin {
    userId: number;
    lastName: string;
    firstName: string;
    email: string;
    phoneNumber: string | null;
    client: object | null;
    professional: object | null;
}

// Donnée utilisateur envoyé 
export interface AuthUserCop {
    userId: number;
    lastName: string;
    firstName: string;
    email: string;
    phoneNumber?: string | null;
    role: Role;
}

export class AuthServ {

    private userRepository: UserRepository;

    constructor(userRepository: UserRepository) {
        this.userRepository = userRepository;
    }

    // ------------------------------------------------------------

    // Le rôle se déduit de la fiche liée : client ou professionnel
    private getRole(user: UserProfilMin): Role {
        if (user.client !== null) {
            return "CLIENT";
        }
        if (user.professional !== null) {
            return "PROFESSIONAL";
        }
        throw new UnauthorizedError("Ce compte n'a aucun rôle");
    }
    // Transforme un utilisateur de la base en AuthUser (sans le hash)
    private toAuthUser(user: UserProfilMin): AuthUserCop {
        return {
            userId: user.userId,
            lastName: user.lastName,
            firstName: user.firstName,
            email: user.email,
            phoneNumber: user.phoneNumber,
            role: this.getRole(user),
        };
    }
    // P2002 est le code de Prisma pour une contrainte d'unicité violée
    private isUniqueConstraintError(error: unknown): boolean {
        if (error === null || typeof error !== "object") {
            return false;
        }
        const prismaError = error as { code?: string };
        return prismaError.code === "P2002";
    }

    // ---------------------------------------------------------

    // REGISTER [LOGIQUE METIER]
    async register(body: RegisterBody): Promise<AuthUserCop> {
        // ----------------- Email deja utiliser ----------------- //
        const emailUtiliser = await this.userRepository.findByEmail(body.email);
        // Produit une erreur : 409
        if (emailUtiliser) {
            throw new ConflictError("Cet email est deja utiliser");
        }

        // -------------- Hashage de mot de passe cree --------- //
        const motdepasseHasher = await hashPassword(body.password);

        // -------- Ajout d'une numero telephone / null --------- //
        let numeroTelephone: string | null = null;

        if (body.phoneNumber) {
            numeroTelephone = body.phoneNumber;
        }

        // NewUserData \> donné envoye pour le repository Utilisateur
        const nouvelUtilisateur: NewUserData = {
            lastName: body.lastName,
            firstName: body.firstName,
            email: body.email,
            passwordHash: motdepasseHasher,
            phoneNumber: numeroTelephone
        }

        try {
            // Creation du compte pour chaque role [CLIENT , PROFESSIONAL]
            if (body.role === "CLIENT") {
                const user = await this.userRepository.createClientUser(nouvelUtilisateur);
                return this.toAuthUser(user);
            }
            const user = await this.userRepository.createProfessionalUser(nouvelUtilisateur);

            return this.toAuthUser(user);

        } catch (error) {
            throw error;
        }

    }

    // LOGIN [LOGIQUE METIER]
    async login(body: LoginBody): Promise<AuthUserCop> {
        const user = await this.userRepository.findByEmail(body.email);

        if (!user) {
            throw new UnauthorizedError("Email ou mot de passe incorrect");
        }

        const motdepasseCorrect = await verifyPassword(body.password, user.passwordHash);

        if (!motdepasseCorrect) {
            throw new UnauthorizedError("Email ou mot de passe incorrect");
        }

        return this.toAuthUser(user);
    }

    // Recuperation d'un Utilisateur [me]
    async getMe(userId: number): Promise<AuthUserCop> {
        const user = await this.userRepository.findById(userId);

        // Le cookie existe mais le compte a ete supprime entre-temps
        if (!user) {
            throw new UnauthorizedError("Session invalide");
        }
        return this.toAuthUser(user);
    }
}