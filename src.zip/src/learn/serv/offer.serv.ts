import { OfferRepository } from "@/repositories/offer.repository";
import { ProfessionalRepository } from "@/repositories/professional.repository";
import { ServiceRepository } from "@/repositories/service.repository";

import { NotFoundError } from "@/lib/errors";

// Données reçues pour proposer un service : la durée et le prix du professionnel
export interface SetOfferData {
    customPrice: number;
    customDuration: number;
}

// Ce que l'on renvoie : prix et durée effectifs (personnalisés ou ceux du catalogue)
export interface OfferItem {
    serviceId: number;
    name: string;
    description: string | null;
    price: number;
    duration: number;
    customPrice: number | null;
    customDuration: number | null;
}

// Forme d'une offre telle que le repository la renvoie
interface OfferRow {
    serviceId: number;
    customPrice: object | null;
    customDuration: number | null;
    service: {
        name: string;
        description: string | null;
        duration: number;
        price: object;
    };
}

export class OfferServ {
    private offerRepo: OfferRepository;
    private ProfRepo: ProfessionalRepository;
    private ServiceRepo: ServiceRepository;

    constructor(offerRepository: OfferRepository, profRepository: ProfessionalRepository, serviceRepository: ServiceRepository) {
        this.offerRepo = offerRepository;
        this.ProfRepo = profRepository;
        this.ServiceRepo = serviceRepository;
    }

    async listByProf(profId: number): Promise<OfferItem[]> {
        await this.checkProfessionalExists(profId);

        const offers = await this.offerRepo.findByProfessional(profId);

        if (!offers) {
            throw new NotFoundError("Service introuvable");
        }

        const result: OfferItem[] = [];

        for (const offer of offers) {
            result.push(this.toOfferItem(offer));
        }

        return result;
    }

    async setOffer(profId: number, serviceId: number, data: SetOfferData): Promise<OfferItem> {
        await this.checkProfessionalExists(profId);

        const serviceCheck = await this.ServiceRepo.findById(serviceId);

        if (!serviceCheck) {
            throw new NotFoundError("Service introuvable");
        }

        const service = await this.offerRepo.upsert(profId, serviceId, data.customPrice, data.customDuration);

        return this.toOfferItem(service);

    }

    async removeOffer(profId: number, serviceId: number) {
        await this.checkProfessionalExists(profId);

        const serviceCheckOffer = await this.offerRepo.findOne(profId, serviceId);

        if (!serviceCheckOffer) {
            throw new NotFoundError("Service introuvable pour ce professinel");
        }

        const serviceRemove = await this.offerRepo.delete(profId, serviceId);

        return { message: "Offre retiré avec succes" };


    }

    // Le compte professionnel peut avoir été supprimé alors que la session existe encore
    private async checkProfessionalExists(professionalId: number) {
        const professional = await this.ProfRepo.findById(professionalId);
        if (!professional) {
            throw new NotFoundError("Professionnel introuvable");
        }
    }

    // Calcule le prix et la durée effectifs, et renvoie des nombres simples
    private toOfferItem(row: OfferRow): OfferItem {
        let price = Number(row.service.price);
        let customPrice: number | null = null;
        if (row.customPrice !== null) {
            customPrice = Number(row.customPrice);
            price = customPrice;
        }

        let duration = row.service.duration;
        if (row.customDuration !== null) {
            duration = row.customDuration;
        }

        return {
            serviceId: row.serviceId,
            name: row.service.name,
            description: row.service.description,
            price: price,
            duration: duration,
            customPrice: customPrice,
            customDuration: row.customDuration,
        };
    }
}