import { ConflictError, NotFoundError } from "@/lib/server/http/errors";
import { ServiceRepository } from "@/repositories/service.repository";
import { ProfessionalRepository } from "@/repositories/professional.repository";
import { normalizeName } from "@/lib/server/booking/text";


const MAX_SUGGESTIONS = 10;

// Données reçues pour créer un service
export interface CreateServiceInput {
    name: string;
    description?: string | null;
    duration: number;
    price: number;
}

// Données envoyé par le repository
export interface ServiceOutput {
    id: number;
    name: string;
    description: string | null;
    duration: number;
    price: object;
}

// Une suggestion : un service existant dont le nom ressemble à la recherche
export interface ServiceSuggestion {
    id: number;
    name: string;
    description: string | null;
    duration: number;
    price: number;
    exact: boolean;
}

export class ServiceServ {
    private serviceRepo: ServiceRepository;
    // Pour la verification du Professionel
    private profRepo: ProfessionalRepository;

    constructor(serviceRepository: ServiceRepository, profRepository: ProfessionalRepository) {
        this.serviceRepo = serviceRepository;
        this.profRepo = profRepository;
    }

    // Consultation de l'ensembles de services (catalogue)
    async listAll() {
        return this.serviceRepo.findAll();
    }

    // Recuperation d'une service particulier
    async getById(id: number) {
        const service = await this.serviceRepo.findById(id);

        if (!service) {
            throw new NotFoundError("Service introuvable");
        }

        return service;
    }

    async createWithOffer(service: CreateServiceInput, professionalId: number) {
        const professional = await this.profRepo.findById(professionalId);

        if (!professional) {
            throw new NotFoundError("Professionel introuvable");
        }

        const newName = normalizeName(service.name);
        const services = await this.serviceRepo.findAll();

        for (const service of services) {
            if (normalizeName(service.name) === newName) {
                throw new ConflictError("Ce service existe deja ,recuperer le au lieu de le creer a nouveau", [
                    "serviceId : " + service.id + "name : " + service.name
                ])
            }
        }

        // Description soit null soit !null
        let description: string | null = null;
        if (service.description !== undefined && service.description !== null) {
            description = service.description;
        }

        const created = await this.serviceRepo.createWithOffer(
            {
                name: service.name,
                description: description,
                duration: service.duration,
                price: service.price
            },
            professionalId
        )

        // Une Prisma.Decimal (object) => Prix en nombre 
        const price = Number(created.price);

        return {
            serviceId: created.id,
            name: created.name,
            description: created.description,
            price: price,
            duration: created.duration,
            customPrice: price,
            customDuration: created.duration,
        }
    }

    /**
     * Lorsque l'utilisateur tape sur la barre de recherche
     * @param name 
     * @returns {Promise<ServiceSuggestion>} Une service suggeré
     */
    async suggest(name: string): Promise<ServiceSuggestion[]> {
        const query = normalizeName(name);

        const services = await this.serviceRepo.findAll();

        // Nom de service identique
        const exactMatches: ServiceSuggestion[] = [];
        // Commence pareil
        const startMatches: ServiceSuggestion[] = [];
        // ceux qui contiennent la recherche
        const otherMatches: ServiceSuggestion[] = [];

        for (const service of services) {
            const serviceName = normalizeName(service.name);

            if (serviceName === query) {
                // On push dans exactMatches service
                exactMatches.push(this.toSuggestion(service, true));
            } else if (serviceName.startsWith(query)) {
                startMatches.push(this.toSuggestion(service, true));
            } else if (serviceName.includes(query)) {
                otherMatches.push(this.toSuggestion(service, true));
            } else if (serviceName.length >= 3 && query.includes(serviceName)) {
                otherMatches.push(this.toSuggestion(service, false));
            }
        }
        const result = exactMatches.concat(startMatches).concat(otherMatches);
        // Retourne les valeur d'une tableau d'index [ start, end ]
        return result.slice(0, MAX_SUGGESTIONS);

    }

    // service => suggestion (prix en nombre)
    private toSuggestion(row: ServiceOutput, exact: boolean): ServiceSuggestion {
        return {
            id: row.id,
            name: row.name,
            description: row.description,
            duration: row.duration,
            price: Number(row.price),
            exact: exact,
        };
    }

}