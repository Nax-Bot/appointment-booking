import { AppointmentRepository, AppointmentStatusValue } from "@/repositories/appointment.repository";

import { ProfessionalRepository } from "@/repositories/professional.repository";
import { OfferRepository } from "@/repositories/offer.repository";
import { AvailabilityRepository } from "@/repositories/availability.repository";
import { UnavailabilityRepository } from "@/repositories/unavailability.repository";

import { ConflictError, NotFoundError, ValidationError } from "@/lib/server/http/errors";

import { toLocalMoment, timeColumnToMinutes, dateColumnToText } from "@/lib/shared/datetime";
import { Role } from "@/lib/server/auth/auth";

// INPUT
export interface CreateAppointmentInput {
    professionalId: number;
    serviceId: number;
    startDatetime: string;
    notes?: string | null;
}

// OUTPUT CREATION
export interface AppointmentItem {
    id: number;
    startDatetime: string;
    endDatetime: string;
    status: string;
    notes: string | null;
    location: string | null;
    priceAtBooking: number | null;
    clientId: number;
    professionalId: number;
    serviceId: number;
}

// READ OUTPUT
export interface AppointmentDetail {
    id: number;
    startDatetime: string;
    endDatetime: string;
    status: string;
    notes: string | null;
    location: string | null;
    priceAtBooking: number | null;
    cancelledAt: string | null;
    cancellationReason: string | null;
    service: {
        id: number;
        name: string;
    };
    professional: {
        userId: number;
        firstName: string;
        lastName: string;
        specialty: string | null;
    };
    client: {
        userId: number;
        firstName: string;
        lastName: string;
        phoneNumber: string | null;
    }
}

// OUTPUT APPOINTMENT REPOSITORY
interface AppointmentRow {
    id: number;
    startDatetime: Date;
    endDatetime: Date;
    status: string;
    notes: string | null;
    location: string | null;
    priceAtBooking: object | null;
    clientId: number;
    professionalId: number;
    serviceId: number;
}

// READ OUTPUT REPOSITORY 
interface AppointmentDetailRow {
    id: number;
    startDatetime: Date;
    endDatetime: Date;
    status: string;
    notes: string | null;
    location: string | null;
    priceAtBooking: object | null;
    cancelledAt: Date | null;
    cancellationReason: string | null;
    clientId: number;
    professionalId: number;
    service: {
        id: number;
        name: string
    };
    client: {
        user: {
            firstName: string;
            lastName: string;
            phoneNumber: string | null
        }
    };
    professional: {
        specialty: string | null;
        user: {
            firstName: string;
            lastName: string
        }
    };
}

// Plage horaire [] / minutes
interface TimeBlock {
    start: number;
    end: number;
}

export class AppointmetnService {
    private appointmentRepo: AppointmentRepository;
    private professionalRepo: ProfessionalRepository;
    private OfferRepo: OfferRepository;
    private availabilityRepo: AvailabilityRepository;
    private unavailabilityRepo: UnavailabilityRepository;

    constructor(
        aptRepo: AppointmentRepository,
        profRepo: ProfessionalRepository,
        offerRepo: OfferRepository,
        availableRepo: AvailabilityRepository,
        unavailableRepo: UnavailabilityRepository
    ) {
        this.appointmentRepo = aptRepo;
        this.professionalRepo = profRepo;
        this.OfferRepo = offerRepo;
        this.availabilityRepo = availableRepo;
        this.unavailabilityRepo = unavailableRepo;
    }

    async create(
        clientId: number,
        input: CreateAppointmentInput
    ): Promise<AppointmentItem> {
        // R1 : le professionnel existe
        const professional = await this.checkProfessionalsExists(input.professionalId);

        // R2 : le professionnel propose ce service
        const offer = await this.profServiceOffer(input.professionalId, input.serviceId);

        // R3 : le début est à une minute pile, et dans le futur
        const start = new Date(input.startDatetime);
        if (start.getUTCSeconds() !== 0 || start.getUTCMilliseconds() !== 0) {
            throw new ValidationError("Le rendez-vous doit commencer à une minute pile (secondes à 00)", []);
        }
        if (start.getTime() <= Date.now()) {
            throw new ValidationError("Le rendez-vous doit être dans le futur", []);
        }


        // Durée et prix effectifs : ceux de l'offre s'ils existent, sinon ceux du catalogue
        let duration = offer.service.duration;
        if (offer.customDuration !== null) {
            duration = offer.customDuration;
        }

        let price = Number(offer.service.price);
        if (offer.customPrice !== null) {
            price = Number(offer.customPrice);
        }

        // L'heure de fin est calculée
        const end = new Date(start.getTime() + duration * 60 * 1000);

        // R4 : le rendez-vous tient dans les disponibilités du professionnel
        const isInside = await this.isInsideAvailabilities(input.professionalId, start, end);
        if (isInside === false) {
            throw new ConflictError("Ce créneau est en dehors des horaires du professionnel");
        }

        // R5 : pas d'indisponibilité sur la période
        const absences = await this.unavailabilityRepo.findOverlapping(input.professionalId, start, end);
        if (absences.length > 0) {
            throw new ConflictError("Le professionnel est indisponible à cette période");
        }

        // R6 : pas d'autre rendez-vous (non annulé) sur la période
        const others = await this.appointmentRepo.findOverlapping(input.professionalId, start, end);
        if (others.length > 0) {
            throw new ConflictError("Ce créneau est déjà réservé");
        }

        let notes: string | null = null;
        if (input.notes !== undefined && input.notes !== null) {
            notes = input.notes;
        }

        const row = await this.appointmentRepo.create({
            clientId: clientId,
            professionalId: input.professionalId,
            serviceId: input.serviceId,
            startDatetime: start,
            endDatetime: end,
            priceAtBooking: price,
            notes: notes,
        });
        return this.toItem(row);
    }

    async listMine(
        userId: number,
        role: Role,
        status: AppointmentStatusValue | undefined
    ): Promise<AppointmentDetail[]> {
        if (role === "CLIENT") {
            const clientRows = await this.appointmentRepo.findForClient(userId, status);
            return this.toDetailList(clientRows);
        }

        const profRows = await this.appointmentRepo.findForProfessional(userId, status);
        return this.toDetailList(profRows);
    }

    async getById(
        userId: number,
        role: Role,
        appointmentId: number
    ): Promise<AppointmentDetail> {
        const row = await this.appointmentRepo.findById(appointmentId);
        if (!row) {
            throw new NotFoundError("Rendez-vous introuvable");
        }

        if (this.isParticipant(row, userId, role) === false) {
            throw new NotFoundError("Rendez-vous introuvable");
        }

        return this.toDetail(row);
    }

    async cancel(
        userId: number,
        role: Role,
        appointmentId: number,
        reason?: string | null
    ): Promise<AppointmentDetail> {
        const row = await this.appointmentRepo.findById(appointmentId);

        if (!row) {
            throw new NotFoundError("Rendez-vous introuvable");
        }

        if (this.isParticipant(row, userId, role) === false) {
            throw new NotFoundError("Rendez-vous introuvable");
        }

        // seul un rendez-vous en attente ou confirmé peut etre annulé
        if (row.status === "CANCELLED") {
            throw new ConflictError("Rendez-vous deja annulé");
        }
        if (row.status !== "PENDING" && row.status !== "CONFIRMED") {
            throw new ConflictError("Un rendez-vous terminé ne peut pas être annulé");
        }

        // On ne peut pas annuler un rendez-vous deja commencé
        if (Date.now() >= row.startDatetime.getTime()) {
            throw new ConflictError("Un rendez-vous déjà commencé ne peut pas être annulé");
        }

        let cleanReason: string | null = null;
        if (reason !== undefined && reason !== null) {
            cleanReason = reason;
        }

        const canceled = await this.appointmentRepo.cancel(appointmentId, new Date(), cleanReason);
        return this.toDetail(canceled);
    }

    private async checkProfessionalsExists(profId: number) {
        const check = await this.professionalRepo.findById(profId);
        if (!check) {
            throw new NotFoundError("Professional Introuvable");
        }

        return check;
    }

    private async profServiceOffer(profId: number, serviceId: number) {
        const check = await this.OfferRepo.findOne(profId, serviceId);
        if (!check) {
            throw new NotFoundError("Ce service n'est pas proposer par ce professionel");
        }

        return check;
    }

    // Soit l'utilisateur est un CLIENT ou un PROFESSIONEL
    private isParticipant(row: AppointmentDetailRow, userId: number, role: Role) {
        if (role === "CLIENT" && row.clientId === userId) {
            return true;
        }
        if (role === "PROFESSIONAL" && row.professionalId === userId) {
            return true;
        }

        return false;
    }

    private async isInsideAvailabilities(
        professionalId: number,
        start: Date,
        end: Date
    ): Promise<boolean> {
        const startLocal = toLocalMoment(start);
        const endLocal = toLocalMoment(end);

        // la date de rendez-vous doit etre la meme jour (date de disponibilite)
        if (startLocal.dateText !== endLocal.dateText) {
            return false;
        }

        // ------ VALIDATION DU DATE DE RENDEZ-VOUS  [DATE DEBUT VALABLE - DATE FIN VALABLE]

        // Liste des disponibilités dans une journée recuperer depuis le Repo availability 
        const blocks = await this.availabilityRepo.findByProfessionalAndDay(professionalId, startLocal.dayOfWeek);

        const validBlocks: TimeBlock[] = [];
        for (const block of blocks) {
            let isValid = true;

            // Date de debut de validation [block.validFrom] > date de debut
            if (block.validFrom !== null && dateColumnToText(block.validFrom) > startLocal.dateText) {
                isValid = false;
            }
            // Date de fin de validation [block.validFrom] < date de debut
            if (block.validTo !== null && dateColumnToText(block.validTo) < startLocal.dateText) {
                isValid = false;
            }

            if (isValid) {
                validBlocks.push({
                    start: timeColumnToMinutes(block.startTime),
                    end: timeColumnToMinutes(block.endTime)
                });
            }

        }

        // Pour verifie si le rendez-vous est couvert jusqu'a sa fin 
        let current = startLocal.minutes;
        let moved = true;

        while (moved && current < endLocal.minutes) {
            moved = false;

            for (const block of validBlocks) {
                if (block.start <= current && block.end > current) {
                    current = block.end;
                    moved = true;
                }
            }
        }

        return current >= endLocal.minutes;

    }

    private toItem(row: AppointmentRow): AppointmentItem {
        let priceAtBooking: number | null = null;
        if (row.priceAtBooking !== null) {
            priceAtBooking = Number(row.priceAtBooking);
        }

        return {
            id: row.id,
            startDatetime: row.startDatetime.toISOString(),
            endDatetime: row.endDatetime.toISOString(),
            status: row.status,
            notes: row.notes,
            location: row.location,
            priceAtBooking: priceAtBooking,
            clientId: row.clientId,
            professionalId: row.professionalId,
            serviceId: row.serviceId,
        };
    }

    private toDetailList(rows: AppointmentDetailRow[]): AppointmentDetail[] {
        const result: AppointmentDetail[] = [];
        for (const row of rows) {
            result.push(this.toDetail(row));
        }
        return result;
    }

    private toDetail(row: AppointmentDetailRow): AppointmentDetail {
        let priceAtBooking: number | null = null;
        if (row.priceAtBooking !== null) {
            priceAtBooking = Number(row.priceAtBooking);
        }

        let cancelledAt: string | null = null;
        if (row.cancelledAt !== null) {
            cancelledAt = row.cancelledAt.toISOString();
        }

        return {
            id: row.id,
            startDatetime: row.startDatetime.toISOString(),
            endDatetime: row.endDatetime.toISOString(),
            status: row.status,
            notes: row.notes,
            location: row.location,
            priceAtBooking: priceAtBooking,
            cancelledAt: cancelledAt,
            cancellationReason: row.cancellationReason,
            service: { id: row.service.id, name: row.service.name },
            professional: {
                userId: row.professionalId,
                firstName: row.professional.user.firstName,
                lastName: row.professional.user.lastName,
                specialty: row.professional.specialty,
            },
            client: {
                userId: row.clientId,
                firstName: row.client.user.firstName,
                lastName: row.client.user.lastName,
                phoneNumber: row.client.user.phoneNumber,
            },
        };
    }
}