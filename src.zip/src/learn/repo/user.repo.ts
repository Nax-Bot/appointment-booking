import { prisma } from "@/lib/server/db/prisma.learn";

async function findUnique() {
    const user = await prisma.user.findUnique({
        where: {
            userId: 12
        }
    })

    return user;
}

async function findMany() {
    const users = await prisma.user.findMany({
        orderBy: [
            { lastName: "asc" }
        ],
        
        take : 3
    })

    return users;
}
async function main() {
    const users = await findMany();

    console.log(users);
}

main()
    .catch((e) => {
        console.error(e)
        process.exit(1)
    })
    .finally(async () => {
        await prisma.$disconnect()
    })